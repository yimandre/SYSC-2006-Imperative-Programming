/* SYSC 2006 Fall 2015 Lab 11. */

double power(double x, int n);
int num_digits(int n);
int occurrences(int a[], int n, int target);

/* Challenge exercise. */
double power2(double x, int n);
